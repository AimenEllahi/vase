import ModelViewerComponent from "./Components/ModelViewerComponent";
import "./App.css";

function App() {
  return (
    <div>
      <ModelViewerComponent />
    </div>
  );
}

export default App;
